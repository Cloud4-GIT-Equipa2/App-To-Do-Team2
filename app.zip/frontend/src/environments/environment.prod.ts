export const environment = {
  production: true,
  apiHost: 'http://localhost:3000/api',
  refreshTokenInterval: 20
};
