export interface Project{
  id?: string,
  name: string;
  userId?: string
}
